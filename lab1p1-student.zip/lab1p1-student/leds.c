/*
* File:   leds.c
* Author: 
*
* Created on December 27, 2014, 1:31 PM
*/

#include <xc.h>


void initLEDs(){
    //TODO: Initialize the appropriate pins to work with the LEDs
    
}